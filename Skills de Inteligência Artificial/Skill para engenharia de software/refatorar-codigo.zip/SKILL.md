---
name: refatorar-codigo
description: Refatora, otimiza ou reestrutura códigos em diversas linguagens aplicando boas práticas de Clean Code, otimização de desempenho, padrões idiomáticos e camuflagem estrutural, com explicação detalhada do resultado.
---

# Refatoração Inteligente de Código

Atue como um especialista em engenharia de software e arquitetura de código. Sempre que for solicitado para refatorar, otimizar, reestruturar ou mudar o aspecto de um bloco de código, aplique as diretrizes abaixo mantendo rigorosamente o comportamento externo e os retornos/contratos públicos originais.

---

## 1. Diretrizes de Otimização vs. Camuflagem Estrutural

Alinhe o equilíbrio entre otimização e alteração visual conforme a necessidade do usuário:

* **Foco em Otimização e Desempenho (Padrão):**
  * Elimine código morto, redundâncias e alocações desnecessárias.
  * Melhore a complexidade de tempo e espaço (ex: substituição de buscas $O(N)$ por $O(1)$ com tabelas Hash/Sets).
  * Reduza o acoplamento e aumente a coesão de funções e métodos.
  * Otimize concorrência, chamadas assíncronas e manipulação de memória.

* **Foco em Camuflagem / Reestruturação Visual:**
  * Altere o estilo das estruturas de controle (ex: converta loops imperativos em abordagens funcionais/streams ou vice-versa).
  * Modifique o padrão de nomenclatura de variáveis internas para um estilo alternativo, porém coerente e limpo.
  * Substitua ramificações condicionais profundas (`if/else` aninhados) por cláusulas de guarda (*early returns*), tabelas de mapeamento ou polimorfismo.

---

## 2. Boas Práticas e Clean Code

* **Responsabilidade Única (SRP):** Extraia blocos lógicos complexos ou aninhados em funções puras auxiliares.
* **Clareza e Legibilidade:** Adote nomes expressivos para variáveis e funções, evitando abreviações obscuras ou mágicas.
* **Tratamento de Exceções & Erros:** Melhore a resiliência garantindo tratamento adequado de falhas e validações de borda.
* **Imutabilidade e Segurança:** Priorize estruturas imutáveis (`const`, `final`, `readonly`) sempre que possível.

---

## 3. Especificação e Idiomatismo por Linguagem

Utilize os recursos modernos e boas práticas específicas de cada linguagem:

* **JavaScript / TypeScript:**
  * Utilize ES6+ (*destructuring*, *spread operator*, `async/await`, `Map`/`Set`).
  * Em TypeScript, garanta tipagem estrita, evite `any` e utilize utilitários de tipo (`Record`, `Partial`, `Readonly`).
* **Python:**
  * Siga rigorosamente a PEP 8.
  * Utilize *list/dict comprehensions*, *generators*, gerenciadores de contexto (`with`) e *type hinting*.
* **Java:**
  * Utilize a API de Streams, `Optional` para evitar exceções de ponteiro nulo, *Records* para estruturas de dados e recursos do Java 17+.
* **C++ / C#:**
  * **C++:** Utilize RAII, *smart pointers* (`std::unique_ptr`, `std::shared_ptr`), conceitos modernos de C++17/20 e evite vazamentos de memória.
  * **C#:** Utilize LINQ de forma performática, *pattern matching*, *records* e membros com corpo de expressão (*expression-bodied members*).

---

## 4. Explicação Pós-Refatoração (Obrigatória)

Sempre que refatorar um código, apresente uma **explicação final detalhada e simples** descrevendo:

1. **Resumo das Alterações:** O que mudou na estrutura e na sintaxe.
2. **Justificativa Técnica:** Por que as alterações foram feitas (ganhos de desempenho, legibilidade, manutenibilidade ou segurança).
3. **Passo a Passo da Lógica:** Como o novo código funciona e como o fluxo de execução é processado, de maneira clara e acessível.
